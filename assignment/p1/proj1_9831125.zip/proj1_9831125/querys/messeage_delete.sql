delete from message 
where sender = 'mmdch' and reciever = 'sk'