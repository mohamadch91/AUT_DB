insert into
  login
values('sk', current_date())