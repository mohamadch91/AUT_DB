insert into
  twitt (user_id, data1, text1)
values('mmdch', current_date(), 'simplwee twitt')