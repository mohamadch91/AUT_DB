select
  *
from
  twitt
where
  USER_ID = 'mmdch'