insert into user values('mmdch', 'mohamad', 'chpupan', SHA2('mamad1380', 256), 'sk', '2001-3-21', '2020-5-6');
insert into user values('sk', 'sss', 'ttt', SHA2('unknown', 256), ':)))', '2001-3-2', '2020-5-6');
