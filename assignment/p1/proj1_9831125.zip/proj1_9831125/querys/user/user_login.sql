select * 
from user 
where ID='mmdch' AND pass=SHA2('mamad1380', 256);