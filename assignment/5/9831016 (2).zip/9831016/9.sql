SELECT Movie.Title, MUX(Rating.Rate)
FROM Movie FULL JOIN RATING
WHERE Movie.mId = Rating.mID
Orderby(Movie.title)