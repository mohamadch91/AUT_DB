SELECT Movie.Name 
FROM Movie
WHERE year = 1998 AND director = 'Steven'  