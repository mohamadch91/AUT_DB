SELECT Artist.Name
FROM Artist OUTER NATURAL JOIN Album
WHERE Album.AlbumId is null
