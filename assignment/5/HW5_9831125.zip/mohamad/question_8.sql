SELECT Movie.name 
FROM Movie
WHERE director = 'steven' AND year = 1998