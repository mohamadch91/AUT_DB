select movie.title
from movie
where movie.year=1998 and movie.director='steven'
