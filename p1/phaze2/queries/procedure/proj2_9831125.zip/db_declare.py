import mysql.connector


def connect():
    db = mysql.connector.connect(
        host='mysql',
        username='root',
        password='root',
        database='twitter',
        port='8081'
    )
    return db
def get_cursor(db):
    return db.cursor(named_tuple=True)
